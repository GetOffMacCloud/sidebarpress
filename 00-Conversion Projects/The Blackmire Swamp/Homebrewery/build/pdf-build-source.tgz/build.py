"""Blackmire Swamp — Homebrewery-style PDF + Homebrewery V3 brew from the source .docx.
Style reference: D&D Adventurers League module layout (white textured page, red small-caps heads,
tan sidebars, parchment chapter banners, red statblocks). Fonts: Solbera's 5e fonts via The Homebrewery."""
import os,re,html,math,json,subprocess
from docxfg import blocks,plain,tcase
DOCX='/mnt/user-data/uploads/The Blackmire Swamp/The Blackmire Swamp Adventure Book.docx'
H=os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------- errata (applied to text)
ERRATA=[  # (find, replace, note)
 ('Base the number of Crocodiles on the party’s progress, resources, etc.. This should showcase the lethality of the swamp without wiping them out.',
  'Adjust the number of crocodiles to the party’s progress and remaining resources; the encounter should show how lethal the swamp is without wiping out the party.',
  'Chapter 1, Wreck of the Reedwake: rewrote the sentence ending “resources, etc..”.'),
 ('add one or two juvenile Crocodiles for five or six characters','add one or two more Juvenile Crocodiles for five or six characters',
  'Chapter 1, Wreck of the Reedwake: creature name capitalized consistently.'),
 ('by the Old Marrow Route with six crew','by the Old Marrow Route with four crew',
  'Handout: The Reedwake Notice: “six crew” changed to “four crew” to match Chapter 1 (two deckhands, a pilot, and a courier).'),
 ('Reward at Favor 2','Reward at +1 (Useful)',
  'Appendix C, Faction Rewards: reward tiers restated on the −2 to +2 standing scale from Running Blackmire (was “Favor 2 / Favor 4”).'),
 ('Reward at Favor 4','Reward at +2 (Trusted)',None),
 ('−4 to +4','−2 to +2','DM Tracking Sheet: faction favor ranges changed from −4 to +4 to −2 to +2, matching Faction Reputation.'),
]
STAT_FIX={'Damage Resistances':('lightning',None),'Condition Immunities':('charmed and frightened while in swamp terrain, poisoned',None)}
ERRATA_NOTES=[n for _,_,n in ERRATA if n]+['Appendix A, Thorn-Heart: the merged “Damage Resistances lightningDamage Immunity: Poison” line split into Damage Resistances (lightning) and Damage Immunities (poison); condition immunities tidied.']
def fix(x):
    for a,b,_ in ERRATA: x=x.replace(a,b)
    return x

# ---------------------------------------------------------------- parse the docx into nodes
def parse():
    B=blocks(DOCX); nodes=[]; started=False; kick=''; skip=False; stat=None; lst=[]
    def flush():
        if lst: nodes.append(('list',list(lst))); lst.clear()
    for b in B:
        if b[0]=='p':
            _,st,x=b; x=fix(x)
            if st=='ChapterKicker': flush(); kick=plain(x); started=True; continue
            if not started: continue
            if st=='Heading1': flush(); stat=None; skip=False; nodes.append(['chapter',kick,plain(x),'']); continue
            if st=='Heading2':
                flush(); stat=None; skip=plain(x)=='Contents'
                if not skip: nodes.append(('h2',x))
                continue
            if skip: continue
            if st=='Heading3': flush(); stat=None; nodes.append(('h3',x)); continue
            if st=='StatText' and stat is not None: stat['lines'].append(plain(x)); continue
            if nodes and nodes[-1][0]=='chapter' and not nodes[-1][3]: nodes[-1][3]=x; continue
            if st=='ListBullet': lst.append(re.sub(r'^\d+\.\s*','',x) if False else x); continue
            flush()
            if st=='SmallText': nodes.append(('caption',x)); continue
            nodes.append(('p',x))
        else:
            _,fill,rows=b
            if not started or skip: continue
            flush(); rows=[[[fix(p) for p in c] for c in r] for r in rows]
            cells=[p for r in rows for c in r for p in c]
            if fill=='355847':
                stat={'name':plain(cells[0]).title(),'lines':[],'abil':[],'tactics':''}; nodes.append(('stat',stat)); continue
            if fill=='E7D7AB' and stat is not None: stat['abil']=[plain(' '.join(c)) for c in rows[1]]; continue
            if fill in('F6F1E5','E7EEF0'):
                if stat is not None and plain(cells[0])=='TACTICS': stat['tactics']=' '.join(cells[1:]); stat=None; continue
                nodes.append(('note',plain(cells[0]),cells[1:])); continue
            if fill=='E8EFE8':
                lab=plain(cells[0])
                nodes.append(('read',cells[1:]) if lab=='READ ALOUD' else ('handout',lab,cells[1:])); continue
            nodes.append(('table',[[' '.join(c) for c in r] for r in rows]))
    flush(); return nodes

# ---------------------------------------------------------------- art placement
OPENER={'The Reedmarch Watches':'open-grimwater','The Broken Fen Hunts':'open-fort','The Deepwater Reach':'open-drift',
        'Into the Black Core':'open-throne','The Heart of Blackmire':'open-grove'}
AFTER_H2={  # image html inserted right after an h2/h3 heading
 'The Four Regions':[('map-schematic.jpg','col','Schematic of Blackmire’s four regions.')],
 'Grimwater Docks':[('col-grimwater.jpg','col',None)],'Mossfall Outpost':[('col-mossfall.jpg','col',None)],
 'Quest Givers and Recurring NPCs':[('npc-group.jpg','wide',None)],
 'Choosing an Expedition Sponsor':[('npc-aster.jpg','colsm','Aster Vale, Veiled Syndicate scholar.')],
 'The Rooted Archive':[('col-archive.jpg','col',None)],
 'Site A: The Rootmaw Labyrinth':[('col-rootmaw.jpg','col',None)],'Site C: The Sunken War Church':[('col-church.jpg','col',None)],
 'Battlefield Features':[('map-grove-schematic.jpg','col','Sunken Druid Grove encounter schematic.')],
 'Living-Wood Focus':[('item-focus.jpg','item',None)],'Sigiled Crocodile Tooth':[('item-tooth.jpg','item',None)],
 'Vial of Blackmire Essence':[('item-vial.jpg','item',None)],'Tide-Thread Rope':[('item-rope.jpg','item',None)],
 'Mudrunner Reedcloak':[('item-cloak.jpg','item',None)],'Throne-Scale Shield':[('item-shield.jpg','item',None)],
 'Ironstake Hunter’s Net':[('item-net.jpg','item',None)],'Resin-Sealed Field Journal':[('item-journal.jpg','item',None)],
}
PORTRAIT_ROW={'The Missing Reedwake':[('npc-rusk.jpg','Captain Rusk Ironstake'),('npc-marrow.jpg','Old Marrow Finch'),('npc-vell.jpg','Sister Vell'),('npc-silt.jpg','Silt')]}
STAT_ART={'Juvenile Crocodile':'art-juvenile-crocodile','Hunting Crocodile':'art-hunting-crocodile','Alpha Crocodile':'art-alpha-crocodile',
 'Swamp Tyrant Crocodile':'art-swamp-tyrant-crocodile','The Thorn-Heart Archdruid Crocodile':'art-the-thorn-heart-archdruid-crocodile',
 'Drowned Sentry':'art-drowned-sentry','Rootbound Sentinel':'art-rootbound-sentinel','Mire-Echo Spirit':'art-mire-echo-spirit'}
GAZETTEER_MAP='map-region.jpg'

def img(src,cls,cap=None):
    c='<figcaption>%s</figcaption>'%cap if cap else ''
    return '<figure class="art %s"><img src="img/%s">%s</figure>'%(cls,src,c)

# ---------------------------------------------------------------- statblocks
SECTS={'TRAITS':None,'ACTIONS':'Actions','BONUS ACTIONS':'Bonus Actions','REACTIONS':'Reactions','LEGENDARY ACTIONS':'Legendary Actions','LAIR ACTIONS':'Lair Actions'}
TOP=('Armor Class','Hit Points','Speed'); MID=('Saving Throws','Skills','Damage Vulnerabilities','Damage Resistances','Damage Immunities','Condition Immunities','Senses','Languages','Challenge')
def stat_parts(s):
    lines=list(s['lines']); typ=lines.pop(0); attrs={}; secs=[]; cur=None
    for l in lines:
        if l in SECTS: cur=[SECTS[l],[]]; secs.append(cur); continue
        n,_,d=l.partition('. ')
        if cur is None:
            if n=='Damage Resistances' and 'Damage Immunity' in d:
                attrs['Damage Resistances']='lightning'; attrs['Damage Immunities']='poison'; continue
            if n=='Condition Immunities': d=d.replace(', Poisoned Condition',', poisoned')
            attrs[n]=d
        else: cur[1].append((n,d))
    return typ,attrs,secs
def rule(): return '<div class="taper"></div>'
def stat_html(s):
    typ,a,secs=stat_parts(s); e=html.escape
    o=['<h4>%s</h4><p class="type">%s</p>'%(e(s['name']),e(typ)),rule()]
    o+=['<p class="attr"><b>%s</b> %s</p>'%(k,e(a[k])) for k in TOP if a.get(k)]
    o.append(rule()+'<table class="abil"><tr>'+''.join('<th>%s</th>'%x for x in ('STR','DEX','CON','INT','WIS','CHA'))+'</tr><tr>'+''.join('<td>%s</td>'%e(x) for x in s['abil'])+'</tr></table>'+rule())
    o+=['<p class="attr"><b>%s</b> %s</p>'%(k,e(a[k])) for k in MID if a.get(k) and a[k] not in('—','-')]
    o.append(rule())
    for title,items in secs:
        if title: o.append('<h5>%s</h5>'%title)
        for n,d in items:
            d=e(d); d=re.sub(r'^(Melee|Ranged|Melee or Ranged) (Weapon|Spell) Attack:',r'<i>\1 \2 Attack:</i>',d); d=d.replace('Hit:','<i>Hit:</i>')
            o.append('<p class="feat"><b><i>%s.</i></b> %s</p>'%(e(n),d))
    big=len(' '.join(s['lines']))>2600
    art=STAT_ART.get(s['name'])
    pre=img(art+'.jpg','beast') if art else ''
    tac='<div class="note tactics"><h6>Tactics</h6><p>%s</p></div>'%s['tactics'] if s['tactics'] else ''
    if big: return pre+'<div class="stat wide"><div class="statcols">%s</div></div>%s'%(''.join(o),tac)
    return '<div class="statwrap">%s<div class="stat">%s</div></div>%s'%(pre,''.join(o),tac)
def stat_md(s):
    typ,a,secs=stat_parts(s); o=['{{monster,frame','## '+s['name'],'*%s*'%typ,'___']
    o+=['**%s** :: %s'%(k,a[k]) for k in TOP if a.get(k)]; o.append('___')
    o.append('|STR|DEX|CON|INT|WIS|CHA|\n|:---:|:---:|:---:|:---:|:---:|:---:|\n|'+'|'.join(s['abil'])+'|'); o.append('___')
    o+=['**%s** :: %s'%(k,a[k]) for k in MID if a.get(k) and a[k] not in('—','-')]; o.append('___')
    for title,items in secs:
        if title: o.append('### '+title)
        for n,d in items:
            d=re.sub(r'^(Melee|Ranged|Melee or Ranged) (Weapon|Spell) Attack:',r'*\1 \2 Attack:*',d).replace('Hit:','*Hit:*')
            o.append('***%s.*** %s\n:'%(n,d))
    o.append('}}')
    if s['tactics']: o.append('\n{{note\n##### Tactics\n%s\n}}'%md_inline(s['tactics']))
    return '\n'.join(o)

# ---------------------------------------------------------------- inline html -> markdown
def md_inline(x):
    x=re.sub(r'<b><i>(.*?)</i></b>',r'***\1***',x); x=re.sub(r'<i><b>(.*?)</b></i>',r'***\1***',x)
    x=re.sub(r'<b>(.*?)</b>',r'**\1**',x); x=re.sub(r'<i>(.*?)</i>',r'*\1*',x)
    return html.unescape(re.sub(r'<[^>]+>','',x))

# ---------------------------------------------------------------- flowchart (SVG)
def box(x,y,w,h,tab,l1,l2=None,small=False):
    fs=15 if not small else 13
    t='<text x="%d" y="%d" class="fc" font-size="%d">%s</text>'%(x+w/2,y+(h/2-4 if l2 else h/2+5),fs,html.escape(l1))
    if l2: t+='<text x="%d" y="%d" class="fc2" font-size="%d">%s</text>'%(x+w/2,y+h/2+16,fs-2,html.escape(l2))
    tb='<path d="M%d %d h22 l6 6 v20 h-28 z" class="tab"/><text x="%d" y="%d" class="tabt">%s</text>'%(x-6,y-14,x+6,y+2,tab) if tab else ''
    return '<rect x="%d" y="%d" width="%d" height="%d" rx="12" class="fbox" filter="url(#sh)"/>%s%s'%(x,y,w,h,tb,t)
def arrow(x1,y1,x2,y2,double=False):
    return '<line x1="%d" y1="%d" x2="%d" y2="%d" class="arr" marker-end="url(#ah)" %s/>'%(x1,y1,x2,y2,'marker-start="url(#ahs)"' if double else '')
def flowchart():
    s=['<svg viewBox="0 0 700 880" class="flow-svg"><defs><filter id="sh"><feDropShadow dx="2" dy="3" stdDeviation="2" flood-opacity=".35"/></filter>',
       '<marker id="ah" markerWidth="5" markerHeight="5" refX="2.5" refY="2.5" orient="auto"><path d="M0 0 L5 2.5 L0 5 z" fill="#7a1f12"/></marker>',
       '<marker id="ahs" markerWidth="5" markerHeight="5" refX="2.5" refY="2.5" orient="auto-start-reverse"><path d="M0 0 L5 2.5 L0 5 z" fill="#7a1f12"/></marker></defs>']
    X,W,Hh=70,250,84; ys=[30,170,310,450,590]
    ch=[('1','The Reedmarch Watches','Chapter 1 · Level 1'),('2','The Broken Fen Hunts','Chapter 2 · Level 2'),('3','The Deepwater Reach','Chapter 3 · Level 3'),
        ('4','Into the Black Core','Chapter 4 · Level 4'),('5','The Heart of Blackmire','Chapter 5 · Level 5')]
    for i,(t,a,b) in enumerate(ch):
        s.append(box(X,ys[i],W,Hh,t,a,b))
        if i<4: s.append(arrow(X+W/2,ys[i]+Hh+6,X+W/2,ys[i+1]-14))
    for i,(t,a,b) in enumerate([('A','The Rootmaw Labyrinth','Root Anchor'),('B','Crocodile Throne Pool','Tide Anchor'),('C','The Sunken War Church','Memory Anchor')]):
        y=372+i*92; s.append(box(420,y,230,70,t,a,b,True)); s.append(arrow(X+W+10,ys[3]+Hh/2,410,y+35,True))
    s.append('<text x="535" y="660" class="fnote">Resolve at least two sites,</text><text x="535" y="678" class="fnote">in any order. Each can be purified,</text><text x="535" y="696" class="fnote">severed, extracted, or left bound.</text>')
    ends=['The Swamp Remembers','The Last Root Is Severed','The Guardian Restored','The Swamp Unbound']
    for i,e in enumerate(ends):
        x=10+i*172; s.append(box(x,760,160,74,None,'Ending %d'%(i+1),e,True)); s.append(arrow(X+W/2,ys[4]+Hh+6,x+80,746))
    s.append('</svg>'); return ''.join(s)

# ---------------------------------------------------------------- nodes -> html
NUM=['Zero','One','Two','Three','Four','Five','Six']
def table_html(rows,wide):
    h='<table class="t5e%s"><thead><tr>%s</tr></thead><tbody>%s</tbody></table>'%(' wide' if wide else '',''.join('<th>%s</th>'%c for c in rows[0]),
       ''.join('<tr>%s</tr>'%''.join('<td>%s</td>'%c for c in r) for r in rows[1:]))
    return h
def render(nodes):
    out=[]; sec=None; inflow=False; parent_h2=''
    def close():
        nonlocal inflow
        if inflow: out.append('</div></section>'); inflow=False
    for n in nodes:
        k=n[0]
        if k=='chapter':
            close()
            if sec=='Adventure at a Glance':
                out.append('<section class="chap brk fcpage"><h1>Adventure Flowchart</h1><p class="fcintro">The chapters run in order, rising one character level each. In Chapter 4 the party resolves the three ritual anchors in any order; their choices decide which of the four endings Chapter 5 reaches.</p>%s</section>'%flowchart())
            _,kick,title,tag=n; m=re.match(r'CHAPTER (\d+) • LEVEL (\d+)',kick); ma=re.match(r'APPENDIX ([A-Z])',kick)
            brk=bool(m or ma) or title in ('Adventure at a Glance','The Truth of Blackmire','Blackmire Gazetteer','Aftermath and Further Adventures')
            out.append('<section class="chap%s">'%(' brk' if brk else ''))
            if m:
                out.append('<div class="banner"><div class="bn-swirl"></div><div class="bn-plate"><span>Chapter %s:</span><span>%s</span></div></div>'%(NUM[int(m.group(1))],html.escape(title)))
                out.append('<div class="flow"><div class="chead"><p class="meta"><b><i>Character Level:</i></b> %s</p><p class="tagline">%s</p></div>'%(m.group(2),tag)); tag=''
            else:
                t='Appendix %s: %s'%(ma.group(1),title) if ma else title
                out.append('<h1>%s</h1><div class="flow">'%html.escape(t))
            inflow=True
            if tag: out.append('<p class="tagline">%s</p>'%tag)
            if title in OPENER: out.append(img(OPENER[title]+'.jpg','opener'))
            if title=='Blackmire Gazetteer': out.append(img(GAZETTEER_MAP,'wide map','The Blackmire Swamp and its four regions.'))
            sec=title
            if title=='Truth of Blackmire': pass
        elif k=='h2':
            t=plain(n[1]); parent_h2=t; out.append('<h2>%s</h2>'%n[1])
            for a in AFTER_H2.get(t,[]): out.append(img(*a))
            if t in PORTRAIT_ROW: out.append('<div class="portraits">%s</div>'%''.join('<figure><img src="img/%s"><figcaption>%s</figcaption></figure>'%p for p in PORTRAIT_ROW[t]))
        elif k=='h3':
            t=plain(n[1]); out.append('<h3>%s</h3>'%n[1])
            for a in AFTER_H2.get(t,[]): out.append(img(*a))
        elif k=='p': out.append('<p>%s</p>'%n[1])
        elif k=='caption': out.append('<p class="caption">%s</p>'%n[1])
        elif k=='list': out.append('<ul>%s</ul>'%''.join('<li>%s</li>'%x for x in n[1]))
        elif k=='table': out.append(table_html(n[1],len(n[1][0])>=4))
        elif k=='read': out.append('<div class="read">%s</div>'%''.join('<p>%s</p>'%p for p in n[1]))
        elif k=='handout': out.append('<div class="handout"><h6>%s</h6>%s</div>'%(html.escape(tcase(n[1])),''.join('<p>%s</p>'%p for p in n[1+1])))
        elif k=='note': out.append('<div class="note"><h6>%s</h6>%s</div>'%(html.escape(tcase(n[1])),''.join('<p>%s</p>'%p for p in n[2])))
        elif k=='stat': out.append(stat_html(n[1]))
        if k=='chapter' and n[2]=='Adventure at a Glance': pass
    close(); return out

# ---------------------------------------------------------------- front & back matter
TITLE='''<div class="cover"><img src="img/cover.jpg"></div>
<div class="titlepage"><p class="code">SP-CV-01</p><p class="ttl">The Blackmire Swamp</p>
<p class="sub">The Curse of the Druids · A Fifth-Edition Adventure</p><div class="redrule"></div>
<p class="blurb">A missing supply barge, a crocodile tooth carved with druidic script, and predators that have begun to hunt together. The swamp is not merely alive. It remembers.</p>
<p class="tier">A regional adventure for four to six characters of levels 1 through 5.<br>Eight to twelve sessions, with milestone advancement.</p>
<div class="credits"><h2>Credits</h2>
<p><b>Written by:</b> EndYourStreamTV (original concept and adventure design)</p>
<p><b>Developed for Fantasy Grounds by:</b> GetOffMacCloud</p>
<p><b>Published by:</b> Sidebar Press</p>
<p><b>Cover and Creature Art:</b> created with Canva for Sidebar Press</p>
<p><b>Interior Art and Maps:</b> from the original adventure book</p>
<p><b>Layout:</b> Sidebar Press, in the style of The Homebrewery</p>
<p><b>Fonts:</b> Bookinsanity, Mr Eaves, Scaly Sans, Nodesto and Solbera Imitation by Solbera (CC BY-SA 4.0), via The Homebrewery</p>
<p><b>Development Notes:</b> corrections made for this edition are listed in Appendix D.</p></div>
<p class="legal">The Blackmire Swamp: The Curse of the Druids © EndYourStreamTV. This edition published by Sidebar Press. This is unofficial fan content for the fifth edition of the world’s greatest roleplaying game; it is not approved or endorsed by Wizards of the Coast. Dungeons &amp; Dragons and D&amp;D are trademarks of Wizards of the Coast LLC.</p></div>'''
def errata_section():
    li=''.join('<li>%s</li>'%html.escape(n) for n in ERRATA_NOTES)
    return ('<section class="chap brk"><h1>Appendix D: Development Notes</h1><div class="flow errata">'
            '<p class="tagline">Changes made by Sidebar Press for this edition. The adventure is otherwise reproduced as written.</p>'
            '<h2>Corrections</h2><ul>%s</ul><h2>Additions</h2><ul><li>Adventure Flowchart page following Adventure at a Glance.</li>'
            '<li>Cover and creature illustrations, and portraits placed beside the NPCs who first appear in Chapters 1 and 2.</li></ul></div></section>')%li

def build_html():
    body=render(parse())
    # Development notes go after Appendix C (the last section)
    doc=('<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="style.css"></head><body>'
         +TITLE+''.join(body)+errata_section()+'</body></html>')
    open(os.path.join(H,'blackmire.html'),'w').write(doc); return doc
if __name__=='__main__':
    build_html(); print('html ok')

# ---------------------------------------------------------------- Homebrewery V3 brew
HOST='https://YOUR-IMAGE-HOST/blackmire/'
def mdimg(src,w='100%',extra=''): return '![](%s%s){width:%s%s}'%(HOST,src,w,extra)
def md_table(rows):
    r=[[md_inline(c).replace('|','/') for c in row] for row in rows]
    return '\n'.join(['| '+' | '.join(r[0])+' |','|'+'|'.join([':--']*len(r[0]))+'|']+['| '+' | '.join(x)+' |' for x in r[1:]])
def brew():
    nodes=parse(); out=[]; words=0; chapter=''
    def page():
        nonlocal words; words=0; out.append('\\page\n{{pageNumber,auto}}\n{{footnote %s}}\n'%chapter.upper())
    def add(md,w):
        nonlocal words
        if words+w>720 and words>150: page()
        out.append(md); words+=w
    out.append('''<!-- SP-CV-01 The Blackmire Swamp — Homebrewery V3 brew (theme: 5ePHB).
Images: upload the files from the "brew-images" folder to Homebrewery (Share > Images) or another permanent host,
then find-and-replace %s with your host's folder URL. Never use Discord CDN links; they expire.
Page breaks: \\page markers are estimated; Homebrewery does not reflow, so nudge any page that overflows. -->
{{frontCover}}
# The Blackmire Swamp
## The Curse of the Druids
___
{{banner A Fifth-Edition Adventure for Levels 1–5}}
{{footnote Written by EndYourStreamTV · Developed for Fantasy Grounds by GetOffMacCloud · Published by Sidebar Press}}
%s
'''%(HOST,mdimg('cover.jpg','100%',',position:absolute,top:0px,left:0px,height:100%')))
    out.append('\\page\n{{wide\n# Credits\n**Written by:** EndYourStreamTV (original concept and adventure design)  \n**Developed for Fantasy Grounds by:** GetOffMacCloud  \n**Published by:** Sidebar Press  \n**Cover and creature art:** created with Canva for Sidebar Press  \n**Interior art and maps:** from the original adventure book\n\n*Unofficial fan content, not approved or endorsed by Wizards of the Coast.*\n}}\n')
    for n in nodes:
        k=n[0]
        if k=='chapter':
            _,kick,title,tag=n; m=re.match(r'CHAPTER (\d+) • LEVEL (\d+)',kick); ma=re.match(r'APPENDIX ([A-Z])',kick)
            if chapter=='Adventure at a Glance':
                chapter='Adventure Flowchart'; page(); out.append('# Adventure Flowchart\n'+mdimg('flowchart.png')+'\n')
            chapter=title; page()
            h='Chapter %s: %s'%(NUM[int(m.group(1))],title) if m else ('Appendix %s: %s'%(ma.group(1),title) if ma else title)
            out.append('# %s\n'%h + ('***Character Level:*** %s\n\n'%m.group(2) if m else '') + ('*%s*\n'%md_inline(tag).strip('*') if tag else ''))
            if title in OPENER: add('{{wide\n%s\n}}\n'%mdimg(OPENER[title]+'.jpg'),230)
            if title=='Blackmire Gazetteer': add('{{wide\n%s\n}}\n'%mdimg(GAZETTEER_MAP),300)
        elif k in('h2','h3'):
            t=plain(n[1]); add('%s %s\n'%('##' if k=='h2' else '###',md_inline(n[1])),25)
            for a in AFTER_H2.get(t,[]): add(mdimg(a[0],'100%' if a[1] in('col','wide') else '60%')+'\n',150)
            if t in PORTRAIT_ROW: add('\n'.join(mdimg(p[0],'48%') for p in PORTRAIT_ROW[t])+'\n',220)
        elif k=='p': t=md_inline(n[1]); add(t+'\n',len(t.split()))
        elif k=='caption': add('*%s*\n'%md_inline(n[1]),15)
        elif k=='list': t='\n'.join('- '+md_inline(x) for x in n[1]); add(t+'\n',len(t.split())+10)
        elif k=='table': t=md_table(n[1]); add(('{{wide\n%s\n}}\n' if len(n[1][0])>=4 else '%s\n')%t,len(t.split())+20*len(n[1]))
        elif k=='read': t='\n\n'.join(md_inline(p) for p in n[1]); add('{{descriptive\n%s\n}}\n'%t,len(t.split())+30)
        elif k=='handout': t='\n\n'.join(md_inline(p) for p in n[2]); add('{{descriptive\n##### %s\n%s\n}}\n'%(tcase(n[1]),t),len(t.split())+30)
        elif k=='note': t='\n\n'.join(md_inline(p) for p in n[2]); add('{{note\n##### %s\n%s\n}}\n'%(tcase(n[1]),t),len(t.split())+30)
        elif k=='stat':
            s=n[1]; art=STAT_ART.get(s['name']); w=len(' '.join(s['lines']).split())+150
            add((mdimg(art+'.jpg','60%')+'\n' if art else '')+('{{wide\n' if w>520 else '')+stat_md(s)+('\n}}' if w>520 else '')+'\n',w)
    chapter='Development Notes'; page()
    out.append('# Appendix D: Development Notes\n*Changes made by Sidebar Press for this edition.*\n## Corrections\n'+'\n'.join('- '+x for x in ERRATA_NOTES)+'\n## Additions\n- Adventure Flowchart page.\n- Cover and creature illustrations; NPC portraits.\n')
    return '\n'.join(out)
if __name__=='__main__':
    open(os.path.join(H,'out','SP-CV-01 The Blackmire Swamp — Homebrewery Brew.md'),'w').write(brew()); print('brew ok')
