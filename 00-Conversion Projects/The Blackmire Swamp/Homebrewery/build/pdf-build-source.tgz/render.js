const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage();
await p.goto('file://'+__dirname+'/blackmire.html',{waitUntil:'networkidle'});await p.evaluate(()=>document.fonts.ready);
await p.pdf({path:__dirname+'/out/blackmire.pdf',preferCSSPageSize:true,printBackground:true});
await p.setContent('<html><head><style>@page{size:letter;margin:0}body{margin:0}img{width:8.5in;height:11in;object-fit:cover;display:block}</style></head><body><img src="file://'+__dirname+'/img/cover.jpg"></body></html>',{waitUntil:'networkidle'});
await p.pdf({path:__dirname+'/out/cover.pdf',preferCSSPageSize:true,printBackground:true});await b.close()})();
