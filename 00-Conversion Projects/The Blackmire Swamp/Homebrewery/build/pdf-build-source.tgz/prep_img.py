"""Prepare book art: crop baked-in label bars, make feathered/torn-edge PNG versions."""
import os,random
from PIL import Image,ImageDraw,ImageFilter,ImageChops
SRC='/mnt/user-data/uploads/The Blackmire Swamp/FGU Kit/build/_pdf'; OUT='/home/claude/hb/img'
def load(n,label=False):
    im=Image.open(os.path.join(SRC,n+'.jpg')).convert('RGB')
    if label: w,h=im.size; im=im.crop((0,0,w,int(h*0.835)))
    return im
def torn(size,sides,feather=40,rough=26,seed=1):
    """alpha mask; sides: string of t,b,l,r to soften with a torn edge"""
    w,h=size; rnd=random.Random(seed); m=Image.new('L',size,255); d=ImageDraw.Draw(m)
    def edge(n): # random walk
        v=0;out=[]
        for i in range(n): v=max(0,min(rough,v+rnd.uniform(-4,4))); out.append(v)
        return out
    step=6
    if 't' in sides:
        e=edge(w//step+2); d.polygon([(0,0)]+[(i*step,e[i]+feather*0.6) for i in range(len(e))]+[(w,0)],fill=0)
    if 'b' in sides:
        e=edge(w//step+2); d.polygon([(0,h)]+[(i*step,h-e[i]-feather*0.6) for i in range(len(e))]+[(w,h)],fill=0)
    if 'l' in sides:
        e=edge(h//step+2); d.polygon([(0,0)]+[(e[i]+feather*0.6,i*step) for i in range(len(e))]+[(0,h)],fill=0)
    if 'r' in sides:
        e=edge(h//step+2); d.polygon([(w,0)]+[(w-e[i]-feather*0.6,i*step) for i in range(len(e))]+[(w,h)],fill=0)
    return m.filter(ImageFilter.GaussianBlur(feather/3))
def save(im,name,sides='',fmt='webp',q=82,**k):
    if sides:
        im=im.convert('RGBA'); im.putalpha(torn(im.size,sides,**k)); base=Image.new('RGBA',im.size,TONE+(255,)); base.alpha_composite(im)
        base.convert('RGB').save(os.path.join(OUT,name+'.jpg'),quality=q+2)
    else: im.save(os.path.join(OUT,name+'.jpg'),quality=q+4)
from PIL import ImageStat
_bg=Image.open('/home/claude/hb/assets/parchmentBackgroundGrayscale.jpg').convert('RGB')
_bg=Image.blend(Image.new('RGB',_bg.size,(255,255,255)),_bg,0.2); _bg.save(os.path.join(OUT,'page-bg.jpg'),quality=80)
TONE=(255,255,255)
def wide(im,ratio):  # landscape crop from a portrait image, centred slightly high
    w,h=im.size; nh=int(w/ratio); y=max(0,int((h-nh)*0.45)); return im.crop((0,y,w,y+nh))
# chapter openers (wide, torn bottom)
for n,c in (('loc-grimwater',1),('loc-fort',2),('loc-drift',3),('loc-throne',4),('loc-grove',5)):
    save(wide(load(n,True),2.1),'open-'+n[4:],'b',feather=50,seed=c)
# column art (torn all round)
for i,n in enumerate(['loc-mossfall','loc-archive','loc-rootmaw','loc-church','loc-drift','loc-grimwater']):
    save(load(n,True),'col-'+n[4:],'tblr',feather=36,seed=10+i)
for i,n in enumerate(['item-focus','item-tooth','item-vial','item-rope','item-cloak','item-shield','item-net','item-journal']):
    im=load(n,True); w,h=im.size; im=im.crop((0,int(h*0.08),w,h)); im.thumbnail((700,700)); save(im,n,'tblr',feather=30,seed=20+i)
for i,n in enumerate(['npc-marrow','npc-vell','npc-rusk','npc-silt','npc-aster']):
    im=load(n); im.thumbnail((700,900)); save(im,n,'tblr',feather=28,seed=30+i)
for i,f in enumerate(sorted(os.listdir(SRC))):
    if f.startswith('art-'):
        im=load(f[:-4]); im.thumbnail((800,800)); save(im,f[:-4],'tblr',feather=40,seed=40+i)
save(load('npc-group'),'npc-group',q=84); save(load('map-region'),'map-region',q=88)
save(load('map-schematic'),'map-schematic',q=88); save(load('map-grove-schematic'),'map-grove-schematic',q=88)
save(load('cover'),'cover',q=88)
print(TONE)
